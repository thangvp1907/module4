package com.codegym.Repository;

import com.codegym.Entity.Blog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryBlog extends JpaRepository<Blog,Integer> {
}
