package com.codegym.Controller;

import com.codegym.Entity.User;
import com.codegym.Service.ServiceUser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/create")
public class ControllerCreateLogin {
    private final ServiceUser serviceUser;

    public ControllerCreateLogin(ServiceUser serviceUser) {
        this.serviceUser = serviceUser;
    }

    @GetMapping("/createlogin")
    public String showCreateUser(Model model) {
        model.addAttribute("user", new User());
        return "view/loginUser/createlogin";
    }

    @PostMapping("/createlogin")
    public String doLogin(@ModelAttribute("user") User user, BindingResult bindingResult, RedirectAttributes redirectAttributes) {
        new User().validate(user, bindingResult);
        if (bindingResult.hasFieldErrors()) {
            return "view/loginUser/createlogin";
        }
        serviceUser.create(user);
        redirectAttributes.addFlashAttribute("mess", "thành công!!!");
        return "redirect:/loginBlog/login";
    }
}
